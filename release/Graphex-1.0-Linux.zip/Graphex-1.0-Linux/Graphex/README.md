# graphex
Ein Programm das im Informatikunterricht der Oberstufe zur Einführung in das Thema "Finden von kürzesten Wegen in Graphen" eingesetzt werden soll.

## Nutzungsanleitung

# Starten von Graphex (WIP)
Herunterladen der aktuellen Version aus dem "release" Ordner. Entpacken der Zipdateie in einen Zielordner. 
Zur Verwendung wird aktuell Java jdk-11 benötigt (zufinden [OpenJdk](https://jdk.java.net/java-se-ri/11), oder unter [AdoptOpenJdk](https://adoptopenjdk.net/).
Wenn diese installiert sind mit der Kommandozeile in den Ordner wechseln in dem die Dateien entpackt sind und dort den Befehl "java -jar graphex-1.0.jar" eingeben.
Danach öffnet sich das Program und kann genutzt werden.
